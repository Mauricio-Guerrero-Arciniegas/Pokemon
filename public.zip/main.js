let name = 'Juan'
name = 30

console.log(name)