import { useRef, useState } from 'react'
import { useName } from '../../context/nameContext'
import { Link, useNavigate } from 'react-router'
import styles from './Home.module.scss'

function Home() {
  const [error, setError] = useState<string | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const navigate = useNavigate()

  const { name, getName } = useName()

  const handleSetName = () => {
    const value = inputRef.current?.value.trim()
    setError(null)

    if (!value) {
      setError('El nombre no puede estar vacío')
      return
    }

    getName(value)
    inputRef.current!.value = ''
    navigate('/pokedex')
  }

  return (
    <div className={styles.container}>
      {!name && (
        <>
          <h1 className={styles.title}>Bienvenidos</h1>
          <p className={styles.subtitle}>Para comenzar ingresa tu nombre</p>
          <input
            type="text"
            ref={inputRef}
            placeholder="Escribe tu nombre"
            className={styles.input}
          />
          <button type="button" onClick={handleSetName} className={styles.button}>
            Comenzar
          </button>
        </>
      )}

      {name && (
        <h2 className={styles.greeting}>
          Hola de nuevo <span className={styles.username}>{name}</span>, ir a tu{' '}
          <Link to="/pokedex" className={styles.link}>Pokedex</Link>
        </h2>
      )}

      {error && <p className={styles.error}>{error}</p>}
    </div>
  )
}

export default Home